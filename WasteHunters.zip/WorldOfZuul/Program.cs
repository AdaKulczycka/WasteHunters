﻿namespace WasteHunters
{
    public class Program
    {
        public static void Main(string[] args) 
        {
            Game game = new();
            game.Play();
        }
    }
}

