namespace WasteHunters
{
    public class Map
    {
        public void PrintMap()
        {
            Console.WriteLine("         ╔═══════╗    ╔═══════╗             ╔═══════╗             ╔═══════╗     ╔═══════╗");
            Console.WriteLine("         ║ BEACH ║════║ BEACH ║═════════════║ BEACH ║═════════════║ BEACH ║═════║ BEACH ║");
            Console.WriteLine("         ╚═══║═══╝    ╚═══║═══╝             ╚═══║═══╝             ╚═══║═══╝     ╚═══║═══╝");
            Console.WriteLine("         ╔═══║═══╗ ╔══════║═══════╗      ╔══════║═══════╗      ╔══════║═══════╗ ╔═══║═══╗");
            Console.WriteLine("         ║ BEACH ║═║   CLEARING   ║══════║   WATERFALL  ║══════║    FOREST    ║═║ BEACH ║");
            Console.WriteLine("         ╚═══║═══╝ ╚══════║═══════╝      ╚══════║═══════╝      ╚══════║═══════╝ ╚═══║═══╝");
            Console.WriteLine("         ╔═══║═══╗ ╔══════║═══════╗      ╔══════║═══════╗      ╔══════║═══════╗ ╔═══║═══╗");
            Console.WriteLine("         ║ BEACH ║═║ DUMPING YARD ║══════║     POND     ║══════║   FACTORY    ║═║ BEACH ║");
            Console.WriteLine("         ╚═══║═══╝ ╚══════║═══════╝      ╚══════════════╝      ╚══════║═══════╝ ╚═══║═══╝");
            Console.WriteLine("             ║            ║         ╔════════════════════════╗        ║             ║    ");
            Console.WriteLine("         ╔═══║═══╗ ╔══════║═══════╗ ║ Bedroom      Bathroom  ║ ╔══════║═══════╗ ╔═══║═══╗");
            Console.WriteLine("         ║ Beach ║═║  RESTAURANT  ║ ║ Kitchen      Hallway   ║═║  CITY CENTER ║═║ BEACH ║");
            Console.WriteLine("         ╚═══║═══╝ ╚══════║═══════╝ ║ Living room            ║ ╚══════║═══════╝ ╚═══║═══╝");
            Console.WriteLine("             ║            ║         ╚════════════════════════╝        ║             ║    ");
            Console.WriteLine("         ╔═══║═══╗ ╔══════║═══════╗      ╔══════════════╗      ╔══════║═══════╗ ╔═══║═══╗");
            Console.WriteLine("         ║ BEACH ║═║ GROCERY STORE║══════║     PARK     ║══════║     MALL     ║═║ BEACH ║");
            Console.WriteLine("         ╚═══║═══╝ ╚══════║═══════╝      ╚══════║═══════╝      ╚══════║═══════╝ ╚═══║═══╝");
            Console.WriteLine("         ╔═══║═══╗    ╔═══║═══╗             ╔═══║═══╗             ╔═══║═══╗     ╔═══║═══╗");
            Console.WriteLine("         ║ BEACH ║════║ BEACH ║═════════════║ BEACH ║═════════════║ BEACH ║═════║ BEACH ║");
            Console.WriteLine("         ╚═══════╝    ╚═══════╝             ╚═══════╝             ╚═══════╝     ╚═══════╝");

        }
    }
}